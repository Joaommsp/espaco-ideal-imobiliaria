/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { PrismaService } from 'src/db/prisma.service';

@Injectable()
export class UserService {
  constructor(private readonly prismaservice: PrismaService) {}

  create(data: CreateUserDto) {
    return this.prismaservice.user.create({
      data: {
        firebaseId: data.firebaseId,
        nome: data.nome,
        email: data.email,
        senha: data.senha,
      },
    });
  }

  findAll() {
    return this.prismaservice.user.findMany();
  }

  findOne(id: number) {
    return this.prismaservice.user.findUnique({
      where: { id },
    });
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return this.prismaservice.user.update({
      where: { id },
      data: {
        nome: updateUserDto.nome,
        firebaseId: updateUserDto.firebaseId,
        email: updateUserDto.email,
        senha: updateUserDto.senha,
      },
    });
  }

  remove(id: number) {
    return this.prismaservice.user.delete({ where: { id } });
  }
}
